#ifndef QUADRATIC_EQUATION_H
#define QUADRATIC_EQUATION_H

#include <stdbool.h>

double solve_equation(double a, double b, double c);

#endif // QUADRATIC_EQUATION_H
